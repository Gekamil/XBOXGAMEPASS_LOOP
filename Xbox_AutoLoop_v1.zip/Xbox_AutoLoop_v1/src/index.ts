import { chromium } from 'patchright';
import { createCursor } from 'ghost-cursor-playwright-port';
import fs from 'fs';
import path from 'path';
import readline from 'readline';
import { execSync } from 'child_process';
import os from 'os'; 
const TelegramBot = require('node-telegram-bot-api');

// ==========================================
// SISTEMA DE MEMORIA (Sabe cuándo te cobran y guarda tu Bot)
// ==========================================
const configPath = path.join(process.cwd(), 'bot_config.json');

function loadConfig() {
    if (fs.existsSync(configPath)) return JSON.parse(fs.readFileSync(configPath, 'utf8'));
    return {};
}

function saveConfig(data: any) {
    const current = loadConfig();
    fs.writeFileSync(configPath, JSON.stringify({ ...current, ...data }, null, 2));
}

// ==========================================
// INSTALADOR DE AUTO-ARRANQUE (INMORTALIDAD)
// ==========================================
function installStartupScript() {
    try {
        const startupFolder = path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
        const vbsPath = path.join(startupFolder, 'XboxBot_Invisible.vbs');
        const vbsContent = `Set WshShell = CreateObject("WScript.Shell")\nWshShell.CurrentDirectory = "${process.cwd()}"\nWshShell.Run "cmd.exe /c npx ts-node src/index.ts --telegram", 0, False`;
        fs.writeFileSync(vbsPath, vbsContent);
        return vbsPath;
    } catch (e) {
        return null;
    }
}

// ==========================================
// EXTRACTOR DE DATOS DE RED (PARA WAKE-ON-LAN)
// ==========================================
function getNetworkInfo() {
    const nets = os.networkInterfaces();
    let info = "";
    for (const name of Object.keys(nets)) {
        for (const net of nets[name] || []) {
            if (net.family === 'IPv4' && !net.internal) {
                info += `   - Adaptador: ${name}\n   - IP: ${net.address}\n   - MAC: ${net.mac}\n\n`;
            }
        }
    }
    return info || "   No se encontraron redes activas.";
}

// ==========================================
// CEREBRO DE AUTOMATIZACIÓN (BUCLE INFINITO)
// ==========================================
function createWindowsTask(formattedDate: string, timeStr: string, isTestMode: boolean = false) {
    const projectPath = process.cwd();
    const ps1Path = path.join(projectPath, 'setup_task.ps1');
    
    const psCommand = `
$ErrorActionPreference = "Stop"
$Action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument '/c cd /d "${projectPath}" && npx ts-node src/index.ts --auto'
$Trigger = New-ScheduledTaskTrigger -Once -At "${formattedDate}T${timeStr}"
$Settings = New-ScheduledTaskSettingsSet -WakeToRun -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
$Settings.StartWhenAvailable = $true 
$Principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest
Register-ScheduledTask -TaskName "GamePassAutoLoop" -Action $Action -Trigger $Trigger -Settings $Settings -Principal $Principal -Force
    `;

    try {
        fs.writeFileSync(ps1Path, psCommand.trim());
        execSync(`powershell -ExecutionPolicy Bypass -File "${ps1Path}"`, { stdio: 'ignore' });
        fs.unlinkSync(ps1Path);
        
        if (isTestMode) {
            console.log(`\n🧪 MODO PRUEBA: El PC ejecutará el bot en 1 MINUTO (${timeStr}).`);
        } else {
            console.log(`\n✅ PROGRAMADO: El bot actuará el ${formattedDate} a las ${timeStr}.`);
        }
    } catch (error) {
        console.log(`\n❌ Error de permisos. Asegúrate de ejecutar como ADMINISTRADOR.`);
        if (fs.existsSync(ps1Path)) fs.unlinkSync(ps1Path);
    }
}

function calculateNextExecution(lastRedemptionStr: string) {
    let [year, month, day] = lastRedemptionStr.split('-').map(Number);
    let nextCharge = new Date(year, month - 1, day);
    const now = new Date();

    while (nextCharge <= now) {
        nextCharge.setMonth(nextCharge.getMonth() + 1);
    }

    let execDate = new Date(nextCharge);
    execDate.setDate(execDate.getDate() - 7);

    if (execDate.getDay() === 6) execDate.setDate(execDate.getDate() - 1);
    if (execDate.getDay() === 0) execDate.setDate(execDate.getDate() - 2);

    execDate.setHours(16, 0, 0, 0);
    return execDate;
}

function scheduleNextRun() {
    const config = loadConfig();
    if (!config.lastRedemption) return;

    const execDate = calculateNextExecution(config.lastRedemption);
    
    saveConfig({ 
        execDate: execDate.toISOString(),
        hasRun: false 
    });

    const execDay = String(execDate.getDate()).padStart(2, '0');
    const execMonth = String(execDate.getMonth() + 1).padStart(2, '0');
    const execYear = execDate.getFullYear();
    const formattedDate = `${execYear}-${execMonth}-${execDay}`;
    
    createWindowsTask(formattedDate, "16:00:00", false);
}

// ==========================================
// CEREBRO DE TELEGRAM (BOTONES DIRECTOS)
// ==========================================
let globalBot: any = null;

const botMenuMarkup = {
    reply_markup: {
        keyboard: [
            [{ text: "/start_gamepass" }, { text: "/estado" }],
            [{ text: "/apagar_pc" }, { text: "/apagar_bot" }]
        ],
        resize_keyboard: true,
        is_persistent: true
    }
};

function sendTelegramMenu(chatId: number, isGreeting = false) {
    let menuText = "🎮 PANEL DE CONTROL XBOX LOOP 🎮\n\n";
    if (isGreeting) {
        menuText += "💻 Tu PC acaba de encenderse y el bot está activo.\n\n";
    } else {
        menuText += "Tu PC está en línea y esperando órdenes.\n\n";
    }
    menuText += "Usa los botones de abajo para ejecutar:\n\n" +
                "👉 /start_gamepass\n(Inicia la auditoría y renueva Xbox)\n\n" +
                "👉 /estado\n(Ver fechas y estado del bot)\n\n" +
                "👉 /apagar_pc\n(Apaga el ordenador físicamente)\n\n" +
                "👉 /apagar_bot\n(Cierra el servidor local pero el PC sigue encendido)";
    
    globalBot.sendMessage(chatId, menuText, botMenuMarkup);
}

function startTelegramBot(isGhostMode = false) {
    const config = loadConfig();
    
    if (!config.telegramToken) return; 

    globalBot = new TelegramBot(config.telegramToken, { polling: true });

    globalBot.on('polling_error', (error: any) => {
        if (error.code === 'ETELEGRAM' && error.message.includes('409')) {
            process.exit(0); 
        }
    });

    globalBot.on('message', (msg: any) => {
        if (msg.chat && msg.chat.id) saveConfig({ chatId: msg.chat.id });
    });

    if (config.chatId && isGhostMode) {
        setTimeout(() => {
            try { sendTelegramMenu(config.chatId, true); } catch (e) {}
        }, 4000); 
    }

    // Comandos de Telegram
    globalBot.onText(/\/(start|menu)/, (msg: any) => {
        if (msg.text === '/start' || msg.text === '/menu') {
            sendTelegramMenu(msg.chat.id, false);
        }
    });

    globalBot.onText(/\/start_gamepass/, async (msg: any) => {
        const chatId = msg.chat.id;
        await globalBot.sendMessage(chatId, "🤖 Sistema activado a distancia.\nIniciando Chromium y comprobando cuenta...", botMenuMarkup);
        await runFullLoop(false, globalBot, chatId);
        await globalBot.sendMessage(chatId, "✅ Proceso completo. El bot sigue a la escucha.");
    });

    globalBot.onText(/\/estado/, async (msg: any) => {
        const chatId = msg.chat.id;
        const currentConfig = loadConfig();
        let statusMsg = "📊 ESTADO DEL SISTEMA:\n\n";
        statusMsg += "🔌 Servidor PC: EN LÍNEA\n";
        
        if (currentConfig.lastRedemption) statusMsg += `🎮 Último Canje: ${currentConfig.lastRedemption}\n`;
        
        if (currentConfig.execDate) {
            const d = new Date(currentConfig.execDate);
            const diffTime = d.getTime() - new Date().getTime();
            const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24));
            
            statusMsg += `📅 Próxima Ejecución: ${d.toLocaleString()}\n`;
            statusMsg += `⏳ Faltan: ${diffDays > 0 ? diffDays + " días" : "¡Hoy (o está retrasado)!"}\n`;
            statusMsg += `✅ Tarea Completada: ${currentConfig.hasRun ? "SÍ" : "NO (Pendiente)"}`;
        } else {
            statusMsg += `⚠️ No hay automatización mensual activada.`;
        }
        
        await globalBot.sendMessage(chatId, statusMsg, botMenuMarkup);
    });

    // NUEVO COMANDO: APAGAR EL PC FÍSICAMENTE
    globalBot.onText(/\/apagar_pc/, (msg: any) => {
        const chatId = msg.chat.id;
        globalBot.sendMessage(chatId, "🔌 Recibido. Apagando el ordenador en 5 segundos... ¡Buenas noches!", { reply_markup: { remove_keyboard: true } });
        setTimeout(() => {
            try {
                execSync('shutdown /s /t 5'); // Comando nativo de Windows para apagar
                process.exit(0);
            } catch (e) {
                globalBot.sendMessage(chatId, "❌ Error: No se pudo apagar el PC por falta de permisos de administrador.");
            }
        }, 1000);
    });

    globalBot.onText(/\/apagar_bot/, (msg: any) => {
        const chatId = msg.chat.id;
        globalBot.sendMessage(chatId, "🛑 Recibido. Apagando el servidor remoto, pero el PC seguirá encendido.", { reply_markup: { remove_keyboard: true } });
        setTimeout(() => { process.exit(0); }, 1000);
    });

    checkEmergencyProtocol(false); 
    setInterval(() => checkEmergencyProtocol(false), 60000); 
}

// 🚨 PROTOCOLO DE EMERGENCIA INSTANTÁNEO
async function checkEmergencyProtocol(exitAfter = false) {
    const config = loadConfig();
    if (!config.execDate || config.hasRun === true) return false;

    const execDateObj = new Date(config.execDate);
    const now = new Date();
    
    if (now >= execDateObj) {
        saveConfig({ hasRun: true }); 
        
        console.log("\n=======================================================");
        console.log(" 🚨 SISTEMA DE RECUPERACIÓN DE EMERGENCIA ACTIVADO");
        console.log("=======================================================");
        console.log(" -> El PC estuvo apagado durante su hora programada.");
        console.log(" -> Arrancando proceso de salvaguarda inmediatamente...\n");
        
        if (config.chatId && globalBot) {
            globalBot.sendMessage(config.chatId, `🚨 RECUPERACIÓN DE TAREA: El PC estuvo apagado cuando le tocaba auditar. ¡Salvando la situación AHORA MISMO!`);
        }
        
        await runFullLoop(exitAfter, globalBot, config.chatId);
        return true;
    }
    return false;
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function showMenu() {
    console.clear();
    console.log("  __  __  ___    ___  __  __             _         ___       _    ");
    console.log("  \\ \\/ / | _ )  / _ \\ \\ \\/ /   /\\  _  _ | |_  ___ | _ ) ___ | |_  ");
    console.log("   >  <  | _ \\ | (_) | >  <   /  \\| || ||  _|/ _ \\| _ \\/ _ \\|  _| ");
    console.log("  /_/\\_\\ |___/  \\___/ /_/\\_\\ /_/\\_\\\\_,_| \\__|\\___/|___/\\___/ \\__| ");
    console.log("===================================================================");
    console.log("|              XBOX GAME PASS LOOP - AUTO AUDIT TOOL              |");
    console.log("===================================================================\n");
    console.log("  [1] 📖 Instrucciones de Uso y Configuración");
    console.log("  [2] 🚀 Ejecutar AHORA (Ciclo Manual)");
    console.log("  [3] ⚙️  GESTIÓN AUTOMÁTICA (Bucle Infinito)");
    console.log("  [4] 📱 GESTIÓN TELEGRAM (Servidor Remoto y Token)");
    console.log("  [5] ❌ Salir\n");
    rl.question("  [#] Selecciona una opción > ", handleMenu);
}

function handleMenu(option: string) {
    switch (option.trim()) {
        case '1': showInstructions(); break;
        case '2': rl.close(); runFullLoop(true); break;
        case '3': handleAutomationSubMenu(); break;
        case '4': handleTelegramSubMenu(); break;
        case '5': process.exit(0); break;
        default: showMenu(); break;
    }
}

// INSTRUCCIONES MINIMALISTAS
function showInstructions() {
    console.clear();
    console.log("===================================================================");
    console.log(" 📖 INSTRUCCIONES RÁPIDAS Y GUÍA DE WAKE-ON-LAN");
    console.log("===================================================================\n");
    console.log("1. LA REGLA DE ORO DE WINDOWS:");
    console.log("   Para que el bot pueda trabajar solo, tu PC nunca debe dormirse.");
    console.log("   -> Ve a 'Sistema > Energía' y pon 'Suspender equipo' en NUNCA.");
    console.log("\n2. CONECTAR TU MÓVIL (TELEGRAM):");
    console.log("   -> Ve a la Opción 4 del menú principal y pega tu Token de BotFather.");
    console.log("   -> Dale a 'Activar Servidor' para hacerlo inmortal (arrancará con Windows).");
    console.log("\n3. ENCENDER EL PC DESDE LA CALLE (WAKE-ON-LAN):");
    console.log("   Descarga la app 'Wake On Lan' en tu móvil. Añade tu portátil usando los");
    console.log("   datos de tu tarjeta de red conectada por CABLE (cópialos de aquí abajo):\n");
    
    console.log(getNetworkInfo()); 
    
    console.log("   Una vez configurado, si el PC está apagado o suspendido, pulsa el botón");
    console.log("   de la app para encenderlo. A los pocos segundos, Telegram te enviará");
    console.log("   el menú automático y podrás ejecutar el código con un solo botón.");
    console.log("   (NOTA: Si mandas el comando antes de que se encienda, quedará en cola");
    console.log("   y se ejecutará solo en cuanto el PC arranque).\n");
    
    rl.question("Presiona ENTER para volver al menú...", () => showMenu());
}

function handleTelegramSubMenu() {
    console.clear();
    console.log("⚙️  CONFIGURACIÓN DEL SERVIDOR TELEGRAM\n");
    
    const config = loadConfig();
    const startupFolder = path.join(process.env.APPDATA || '', 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup');
    const vbsPath = path.join(startupFolder, 'XboxBot_Invisible.vbs');
    const isVbsActive = fs.existsSync(vbsPath);

    if (!config.telegramToken) {
        console.log(`   🔴 ESTADO: Ningún Token configurado (No puede funcionar).\n`);
    } else if (isVbsActive) {
        console.log(`   🟢 ESTADO: ACTIVO (Inmortal. Escuchando al móvil de fondo).\n`);
    } else {
        console.log(`   🟡 ESTADO: DESACTIVADO (Token guardado, pero no arrancará con Windows).\n`);
    }

    console.log("  [1] 🚀 ACTIVAR Servidor en Segundo Plano (Hacer Inmortal)");
    console.log("  [2] 🛑 DESACTIVAR Servidor (Borrar Auto-arranque)");
    console.log("  [3] 🔑 Configurar / Cambiar Token Personal de BotFather");
    console.log("  [4] 🔙 Volver al menú principal\n");

    rl.question("  [#] Elige > ", (opt) => {
        if (opt === '1') {
            if (!config.telegramToken) {
                console.log("\n❌ ERROR: Primero debes configurar el Token (Opción 3).");
            } else {
                const vp = installStartupScript();
                try {
                    if (vp) execSync(`wscript.exe "${vp}"`);
                    console.log("\n✅ SERVIDOR ACTIVADO EN SEGUNDO PLANO.");
                    console.log("   - El bot funcionará siempre de fondo incluso si reinicias.");
                } catch(e) {}
            }
            rl.question("\nPresiona ENTER para volver...", () => handleTelegramSubMenu());
        } else if (opt === '2') {
            if (fs.existsSync(vbsPath)) {
                fs.unlinkSync(vbsPath);
                console.log("\n✅ Auto-arranque desactivado. El bot ya no se encenderá con el PC.");
            } else {
                console.log("\n⚠️ El bot ya estaba desactivado.");
            }
            rl.question("\nPresiona ENTER para volver...", () => handleTelegramSubMenu());
        } else if (opt === '3') {
            rl.question("\n-> Pega aquí tu Token de Telegram: ", (token) => {
                if (token.length > 20 && token.includes(':')) {
                    saveConfig({ telegramToken: token.trim() });
                    console.log("\n✅ Token guardado correctamente. Ya puedes darle a la Opción 1.");
                } else {
                    console.log("\n❌ Token inválido.");
                }
                rl.question("\nPresiona ENTER...", () => handleTelegramSubMenu());
            });
        } else {
            showMenu();
        }
    });
}

function handleAutomationSubMenu() {
    console.clear();
    console.log("⚙️  CONFIGURACIÓN DE AUTOMATIZACIÓN INTELIGENTE\n");
    
    const config = loadConfig();
    if (config.execDate && !config.hasRun) {
        const dateObj = new Date(config.execDate);
        const diffTime = dateObj.getTime() - new Date().getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24));

        console.log(`   🟢 ESTADO ACTUAL: ACTIVO (Bucle Infinito)`);
        if (config.lastRedemption) console.log(`   🎮 Último Canje guardado: ${config.lastRedemption}`);
        console.log(`   📅 Próxima ejecución: ${dateObj.toLocaleString()} (Faltan ${diffDays > 0 ? diffDays : 0} días)\n`);
    } else {
        console.log(`   🔴 ESTADO ACTUAL: DESACTIVADO (o ya completado)\n`);
    }

    console.log("  [1] ACTIVAR (Ajustar último cobro y programar Bucle)");
    console.log("  [2] 🧪 MODO PRUEBA (Ejecutar en 1 MINUTO para testear)");
    console.log("  [3] 🛑 DESACTIVAR (Borrar tarea y vaciar memoria)");
    console.log("  [4] 🔙 Volver\n");
    
    rl.question("  [#] Elige > ", (opt) => {
        if (opt === '1') {
            installStartupScript(); 
            rl.question("\n📅 ¿Cuándo fue la ÚLTIMA vez que canjeaste el Game Pass? (DD/MM/YYYY): ", (f) => {
                const p = f.split('/');
                if (p.length === 3) {
                    const rawYear = p[2];
                    const rawMonth = p[1].padStart(2, '0');
                    const rawDay = p[0].padStart(2, '0');
                    const lastRedemptionStr = `${rawYear}-${rawMonth}-${rawDay}`;

                    saveConfig({ lastRedemption: lastRedemptionStr });
                    scheduleNextRun(); 
                    
                    console.log("\n✅ Bucle automático activado e incrustado en el sistema.");
                } else { console.log("\n❌ Formato incorrecto."); }
                rl.question("\nPresiona ENTER...", () => showMenu());
            });
        } else if (opt === '2') {
            installStartupScript(); 
            const d = new Date(); 
            d.setMinutes(d.getMinutes() + 1);
            
            saveConfig({ execDate: d.toISOString(), hasRun: false });

            const execDay = String(d.getDate()).padStart(2, '0');
            const execMonth = String(d.getMonth() + 1).padStart(2, '0');
            const fDate = `${d.getFullYear()}-${execMonth}-${execDay}`;
            const fTime = `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}:00`;
            
            createWindowsTask(fDate, fTime, true);
            rl.question("\nPresiona ENTER...", () => showMenu());
        } else if (opt === '3') {
            try {
                execSync(`schtasks /Delete /TN "GamePassAutoLoop" /F`, { stdio: 'ignore' });
                saveConfig({ execDate: null, lastRedemption: null, hasRun: true });
                console.log("\n✅ Automatización y memoria borradas.");
            } catch (e) { console.log("\n⚠️ No había ninguna tarea activa."); }
            rl.question("\nPresiona ENTER...", () => showMenu());
        } else { showMenu(); }
    });
}

// ==========================================
// TU CÓDIGO PERFECTO INTACTO 
// ==========================================
async function runFullLoop(exitOnFinish = true, botObj?: any, chatId?: number) {
    const isSilent = process.argv.includes('--telegram');

    if (!isSilent) {
        console.log("\n[▶] Iniciando Motor de Automatización Xbox...");
        console.log(" -> Cargando sesión y configuraciones...");
    }

    if (process.argv.includes('--auto') || !exitOnFinish) {
        if (!isSilent) console.log("📡 Esperando 15 segundos para asegurar conexión a Internet (Wi-Fi)...");
        await new Promise(resolve => setTimeout(resolve, 15000));
    }

    const statePath = path.join(process.cwd(), 'auth', 'state.json');

    if (!fs.existsSync(statePath)) {
        console.error('❌ Error: Archivo de sesión no encontrado.');
        if (botObj && chatId) botObj.sendMessage(chatId, "❌ Error crítico: Archivo de estado no encontrado. El bot se ha detenido.");
        if (exitOnFinish) process.exit(1);
        return;
    }

    if (!isSilent) console.log("🌐 Abriendo navegador fantasma (Esto puede tardar unos segundos)...");
    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext({ storageState: statePath });
    const page = await context.newPage();
    const cursor = createCursor(page as any);

    async function smartClick(locatorToClick: any, name: string) {
        if (!isSilent) console.log(` -> Enfocando: ${name}`);
        await locatorToClick.evaluate((node: HTMLElement) => {
            node.scrollIntoView({ block: 'center', inline: 'center' });
        });
        await page.waitForTimeout(1500);
        try {
            await cursor.click(await locatorToClick.elementHandle() as any);
            if (!isSilent) console.log(` -> [✓] Clic fantasma exitoso en ${name}`);
        } catch (e) {
            if (!isSilent) console.log(` -> [!] Clic fantasma falló. Forzando clic nativo (Bypass)...`);
            await locatorToClick.click({ force: true });
        }
    }

    try {
        if (!isSilent) console.log('[1/6] Comprobando estado actual de la suscripción...');
        await page.goto('https://account.microsoft.com/services/pcgamepass/details#billing', { waitUntil: 'networkidle' });

        let hasSubscription = false;
        const firstCancelLink = page.getByText('Cancelar la suscripción', { exact: false }).last();
        
        try {
            if (!isSilent) console.log(' -> Buscando si existe la opción de cancelar...');
            await firstCancelLink.waitFor({ state: 'visible', timeout: 20000 });
            hasSubscription = true;
            if (!isSilent) console.log(' -> [!] Suscripción ACTIVA detectada. Iniciando protocolo de cancelación.');
            if (botObj && chatId) botObj.sendMessage(chatId, "⚠️ Suscripción Activa detectada. Iniciando proceso de Cancelación y Reembolso...");
        } catch (error) {
            if (!isSilent) console.log(' -> [!] NO hay suscripción activa (o ya fue cancelada). Pasando a recomprar.');
            if (botObj && chatId) botObj.sendMessage(chatId, "⚠️ No hay suscripción activa. Pasando directo a la zona de compras...");
        }

        if (hasSubscription) {
            await smartClick(firstCancelLink, "Primer enlace de cancelar");

            if (!isSilent) console.log('[3/6] Esperando a que cargue la página de retención...');
            const keepSubBtn = page.getByRole('button', { name: /Mantener/i });
            await keepSubBtn.waitFor({ state: 'visible', timeout: 20000 });

            const blueCancelBtn = page.getByRole('button', { name: /Cancelar/i }).first();
            await smartClick(blueCancelBtn, "Botón azul de retención");

            if (!isSilent) console.log('[4/6] Esperando el Modal de Reembolso...');
            const refundText = page.getByText(/reembolsaremos/i);
            await refundText.waitFor({ state: 'visible', timeout: 15000 });

            await smartClick(refundText, "Recuadro de reembolso (Hoy)");

            if (!isSilent) {
                console.log('⚠️ ATENCIÓN: El bot está listo para la cancelación final.');
                console.log('⚠️ Esperando 5 segundos. Comprueba tu pantalla.');
            }
            await page.waitForTimeout(5000); 

            if (!isSilent) console.log(' -> Aislando el botón final en la ventana emergente...');
            const finalCancelBtn = page.locator('[role="dialog"] button:has-text("Cancelar la suscripción")').first();
            
            try {
                await smartClick(finalCancelBtn, "BOTÓN FINAL DE CANCELACIÓN");
            } catch (error) {
                if (!isSilent) console.log(' -> [!] El ratón se bloqueó. Calculando coordenadas puras (X, Y)...');
                const box = await finalCancelBtn.boundingBox();
                if (box) {
                    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 10 });
                    await page.waitForTimeout(300);
                    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
                    if (!isSilent) console.log(' -> [✓] Clic ejecutado por coordenadas físicas.');
                } else {
                    if (!isSilent) console.log(' -> [!] Coordenadas fallaron. Inyectando clic JavaScript directo...');
                    await finalCancelBtn.evaluate((btn: HTMLElement) => btn.click());
                }
            }

            if (!isSilent) console.log('✅ CANCELACIÓN COMPLETADA. El dinero vuelve a tu saldo.');
            if (botObj && chatId) botObj.sendMessage(chatId, "✅ ¡Cancelación y reembolso completados! El dinero vuelve a tu cuenta. Navegando a la tienda de Xbox...");
            if (!isSilent) console.log('[5/6] Esperando 15 segundos para actualización de bases de datos...');
            await page.waitForTimeout(15000); 
        }

        if (!isSilent) console.log('\n[▶] Navegando a la tienda de Xbox...');
        await page.goto('https://www.xbox.com/es-es/games/store/pc-game-pass/cfq7ttc0kgq8', { waitUntil: 'domcontentloaded' });

        if (!isSilent) console.log(' -> Esperando 6 segundos para sincronización de sesión de Microsoft...');
        await page.waitForTimeout(6000);

        const cookiesBtn = page.locator('button:has-text("Aceptar"), button:has-text("Accept")').first();
        if (await cookiesBtn.isVisible()) {
            await smartClick(cookiesBtn, "Aceptar Cookies");
        }

        if (!isSilent) console.log('Buscando el bloque verde de "UNIRSE"...');
        const joinBtn = page.locator('a:has-text("UNIRSE"), button:has-text("UNIRSE"), a:has-text("Unirse")').first();
        await joinBtn.waitFor({ state: 'visible', timeout: 15000 });
        await smartClick(joinBtn, "Botón verde de UNIRSE");

        if (!isSilent) console.log('Interactuando con la pasarela de pago (Esperando carga de seguridad)...');
        await page.waitForTimeout(10000); 
        
        let paymentSuccess = false;
        if (!isSilent) console.log(' -> Iniciando perforación del Iframe bancario...');

        const finalBuyBtn = page.frameLocator('iframe').getByText(/COMPRAR AHORA/i).last();

        try {
            if (!isSilent) console.log(' -> Esperando a que el botón "COMPRAR AHORA" sea visible dentro del escudo...');
            await finalBuyBtn.waitFor({ state: 'visible', timeout: 15000 });
            if (!isSilent) console.log(' -> [✓] ¡Botón detectado dentro del Iframe!');

            const box = await finalBuyBtn.boundingBox();
            if (box) {
                if (!isSilent) console.log(' -> Calculando coordenadas de impacto...');
                await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 5 });
                await page.waitForTimeout(300);
                await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
                if (!isSilent) console.log(' -> [✓] ¡Clic matemático ejecutado en el centro del botón!');
            } else {
                if (!isSilent) console.log(' -> [!] Coordenadas ocultas por CSS. Lanzando clic nativo forzado...');
                await finalBuyBtn.click({ force: true });
            }
            paymentSuccess = true;

        } catch (e) {
            if (!isSilent) console.log(' -> [!] frameLocator falló. Plan B: Escaneo profundo manual en bucle...');
            for (const frame of page.frames()) {
                try {
                    const fallbackBtn = frame.getByText(/COMPRAR AHORA/i).last();
                    if (await fallbackBtn.isVisible({ timeout: 2000 })) {
                        await fallbackBtn.click({ force: true });
                        if (!isSilent) console.log(' -> [✓] ¡Clic forzado logrado en el escaneo manual!');
                        paymentSuccess = true;
                        break;
                    }
                } catch (err) {}
            }
        }

        if (paymentSuccess) {
            if (!isSilent) console.log('✅ RE-SUSCRIPCIÓN COMPLETADA CON ÉXITO.');
            if (botObj && chatId) botObj.sendMessage(chatId, "🎉 ¡MISIÓN CUMPLIDA! Hemos comprado el Game Pass de nuevo.");
            
            const now = new Date();
            const todayStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
            saveConfig({ lastRedemption: todayStr, hasRun: true }); 
            scheduleNextRun(); 
            
            await page.waitForTimeout(8000); 
        } else {
            if (!isSilent) console.log('⚠️ ALERTA: Microsoft ha bloqueado el acceso total al Iframe.');
            if (!isSilent) console.log('⚠️ Por favor, dale al botón verde de "COMPRAR AHORA" tú mismo en la ventana.');
            if (botObj && chatId) botObj.sendMessage(chatId, "⚠️ Microsoft nos bloqueó el pago final. Ve a la pantalla del PC y termina la compra a mano.");
            await page.waitForTimeout(60000); 
        }

    } catch (error) {
        if (!isSilent) console.error('❌ Error crítico durante la ejecución:', error);
        if (botObj && chatId) botObj.sendMessage(chatId, "❌ Error crítico. Revisa la consola del PC.");
    } finally {
        if (!isSilent) console.log('Cerrando navegador...');
        await browser.close();
        if (!isSilent) console.log('✅ Liberando memoria RAM del sistema...');
        if (exitOnFinish) process.exit(0); 
    }
}

// ==========================================
// PUNTO DE ENTRADA (Manejador de la Consola / Demonio)
// ==========================================
(async () => {
    if (process.argv.includes('--telegram')) {
        startTelegramBot(true);
    } else if (process.argv.includes('--auto')) {
        console.log("=====================================================");
        console.log(" ⏰ MODO AUTOMÁTICO INICIADO POR WINDOWS");
        console.log("=====================================================\n");
        saveConfig({ hasRun: true });
        runFullLoop(true);
    } else {
        const emergencyTriggered = await checkEmergencyProtocol(true);
        if (!emergencyTriggered) {
            showMenu();
        }
    }
})();