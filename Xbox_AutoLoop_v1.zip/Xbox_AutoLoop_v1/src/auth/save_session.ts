import { chromium } from 'patchright';
import fs from 'fs';
import path from 'path';
import readline from 'readline';

async function saveSession() {
    const authDir = path.join(process.cwd(), 'auth');
    if (!fs.existsSync(authDir)) fs.mkdirSync(authDir);

    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext();
    const page = await context.newPage();

    console.log('--- SESIÓN DE AUTENTICACIÓN ---');
    console.log('1. Loguéate en tu cuenta de Microsoft.');
    console.log('2. Llega hasta la página de tus suscripciones.');
    console.log('3. IMPORTANTE: NO CIERRES EL NAVEGADOR CON LA X.');
    console.log('4. Cuando estés listo, vuelve a esta pantalla negra y presiona ENTER.');

    await page.goto('https://account.microsoft.com/services/');

    // Creamos un lector de teclado en la terminal
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

    rl.question('\n[PRESIONA ENTER AQUÍ CUANDO ESTÉS LOGUEADO PARA GUARDAR Y CERRAR]', async () => {
        console.log('Guardando datos de sesión de forma segura...');
        const statePath = path.join(authDir, 'state.json');
        
        // Guardamos las cookies MIENTRAS el navegador sigue vivo
        await context.storageState({ path: statePath });
        console.log('✅ ¡Sesión guardada con éxito en auth/state.json!');
        
        // Ahora sí, el bot cierra el navegador
        await browser.close();
        rl.close();
        process.exit(0);
    });
}

saveSession();